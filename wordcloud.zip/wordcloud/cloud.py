# 导入wordcloud模块和matplotlib模块
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from scipy.misc import imread
# 读取一个txt文件
def aaa():
    text = open('test.txt','r').read()
    return text

text = aaa()
# 读入背景图片
bg_pic = imread('222.jpg')
# 生成词云
wordcloud = WordCloud(font_path='C:\Windows\Fonts\segoeprb.ttf',mask=bg_pic,background_color='white',scale=1.5).generate(text)
# image_colors = ImageColorGenerator(bg_pic)
# 显示词云图片
plt.imshow(wordcloud)
plt.axis('off')
plt.savefig("result.jpg")
plt.show()